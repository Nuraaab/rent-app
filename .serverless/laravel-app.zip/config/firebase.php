<?php
return [
    'credentials' => env('FIREBASE_CREDENTIALS', base_path('storage/firebase/firebase_credentials.json')),
];
